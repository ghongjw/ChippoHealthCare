package _12_1_memberRevise;

public class MRDAO {

}
