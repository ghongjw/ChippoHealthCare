package _4_perchase;

public class PcDTO {
int pcMonth,pcPTCount,expire_year,expire_month,expire_day,ptCount,addPtCount;

public int getAddPtCount() {
	return addPtCount;
}

public void setAddPtCount(int addPtCount) {
	this.addPtCount = addPtCount;
}

public int getExpire_year() {
	return expire_year;
}

public void setExpire_year(int expire_year) {
	this.expire_year = expire_year;
}

public int getExpire_month() {
	return expire_month;
}

public void setExpire_month(int expire_month) {
	this.expire_month = expire_month;
}

public int getExpire_day() {
	return expire_day;
}

public void setExpire_day(int expire_day) {
	this.expire_day = expire_day;
}

public int getPtCount() {
	return ptCount;
}

public void setPtCount(int ptCount) {
	this.ptCount = ptCount;
}

public int getPcMonth() {
	return pcMonth;
}

public void setPcMonth(int pcMonth) {
	this.pcMonth = pcMonth;
}

public int getPcPTCount() {
	return pcPTCount;
}

public void setPcPTCount(int pcPTCount) {
	this.pcPTCount = pcPTCount;
}
}
