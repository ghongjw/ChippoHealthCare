package _23_findpw;

public class FindPwDTO {
		private String name;
		private String moblie;
		private int confirmNum;
		public int getConfirmNum() {
			return confirmNum;
		}
		public void setConfirmNum(int confirmNum) {
			this.confirmNum = confirmNum;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
	
		public String getMoblie() {
			return moblie;
		}
		public void setMoblie(String moblie) {
			this.moblie = moblie;
		}
	
	
}
