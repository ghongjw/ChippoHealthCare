package _5_book;

public class BoDTO {
private String trainername,point,t1,t1User,t2,t2User,t3,t3User,t4,t4User,t5,t5User,t6,t6User,t7,t7User;
public String getT8() {
	return t8;
}

public void setT8(String t8) {
	this.t8 = t8;
}

public String getT8User() {
	return t8User;
}

public void setT8User(String t8User) {
	this.t8User = t8User;
}

public String getT9() {
	return t9;
}

public void setT9(String t9) {
	this.t9 = t9;
}

public String getT9User() {
	return t9User;
}

public void setT9User(String t9User) {
	this.t9User = t9User;
}

private String t8,t8User,t9,t9User;

public String getTrainername() {
	return trainername;
}

public void setTrainername(String trainername) {
	this.trainername = trainername;
}

public String getPoint() {
	return point;
}

public void setPoint(String point) {
	this.point = point;
}

public String getT1() {
	return t1;
}

public void setT1(String t1) {
	this.t1 = t1;
}

public String getT1User() {
	return t1User;
}

public void setT1User(String t1User) {
	this.t1User = t1User;
}

public String getT2() {
	return t2;
}

public void setT2(String t2) {
	this.t2 = t2;
}

public String getT2User() {
	return t2User;
}

public void setT2User(String t2User) {
	this.t2User = t2User;
}

public String getT3() {
	return t3;
}

public void setT3(String t3) {
	this.t3 = t3;
}

public String getT3User() {
	return t3User;
}

public void setT3User(String t3User) {
	this.t3User = t3User;
}

public String getT4() {
	return t4;
}

public void setT4(String t4) {
	this.t4 = t4;
}

public String getT4User() {
	return t4User;
}

public void setT4User(String t4User) {
	this.t4User = t4User;
}

public String getT5() {
	return t5;
}

public void setT5(String t5) {
	this.t5 = t5;
}

public String getT5User() {
	return t5User;
}

public void setT5User(String t5User) {
	this.t5User = t5User;
}

public String getT6() {
	return t6;
}

public void setT6(String t6) {
	this.t6 = t6;
}

public String getT6User() {
	return t6User;
}

public void setT6User(String t6User) {
	this.t6User = t6User;
}

public String getT7() {
	return t7;
}

public void setT7(String t7) {
	this.t7 = t7;
}

public String getT7User() {
	return t7User;
}

public void setT7User(String t7User) {
	this.t7User = t7User;
}

}
