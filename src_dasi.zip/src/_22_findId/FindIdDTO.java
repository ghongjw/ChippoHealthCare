package _22_findId;

public class FindIdDTO {
		private String name;
		private String moblie;
		private String confirmNum;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
	
		public String getMoblie() {
			return moblie;
		}
		public void setMoblie(String moblie) {
			this.moblie = moblie;
		}
	
		public String getconfirmNum() {
			return confirmNum;
	}
	
		public void setconfirmNum(String confirmtest) {
			this.confirmNum = confirmtest;
	}
	
}
