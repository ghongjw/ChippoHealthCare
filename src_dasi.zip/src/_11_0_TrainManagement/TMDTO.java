package _11_0_TrainManagement;

public class TMDTO {
	private String trainername, point, date, t1, t2, t3, t4, t5, t6, t7, t8, t9;
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	private String t1_user, t2_user, t3_user, t4_user, t5_user, t6_user, t7_user, t8_user, t9_user;
	private String DBempty;

	public String getTrainername() {
		return trainername;
	}

	public String getT1_user() {
		return t1_user;
	}

	public void setT1_user(String t1_user) {
		this.t1_user = t1_user;
	}

	public String getT2_user() {
		return t2_user;
	}

	public void setT2_user(String t2_user) {
		this.t2_user = t2_user;
	}

	public String getT3_user() {
		return t3_user;
	}

	public void setT3_user(String t3_user) {
		this.t3_user = t3_user;
	}

	public String getT4_user() {
		return t4_user;
	}

	public void setT4_user(String t4_user) {
		this.t4_user = t4_user;
	}

	public String getT5_user() {
		return t5_user;
	}

	public void setT5_user(String t5_user) {
		this.t5_user = t5_user;
	}

	public String getT6_user() {
		return t6_user;
	}

	public void setT6_user(String t6_user) {
		this.t6_user = t6_user;
	}

	public String getT7_user() {
		return t7_user;
	}

	public void setT7_user(String t7_user) {
		this.t7_user = t7_user;
	}

	public String getT8_user() {
		return t8_user;
	}

	public void setT8_user(String t8_user) {
		this.t8_user = t8_user;
	}

	public String getT9_user() {
		return t9_user;
	}

	public void setT9_user(String t9_user) {
		this.t9_user = t9_user;
	}

	public void setTrainername(String trainername) {
		this.trainername = trainername;
	}

	public String getPoint() {
		return point;
	}

	public void setPoint(String point) {
		this.point = point;
	}

	public String getT1() {
		return t1;
	}

	public void setT1(String t1) {
		this.t1 = t1;
	}

	public String getT2() {
		return t2;
	}

	public void setT2(String t2) {
		this.t2 = t2;
	}

	public String getT3() {
		return t3;
	}

	public void setT3(String t3) {
		this.t3 = t3;
	}

	public String getT4() {
		return t4;
	}

	public void setT4(String t4) {
		this.t4 = t4;
	}

	public String getT5() {
		return t5;
	}

	public void setT5(String t5) {
		this.t5 = t5;
	}

	public String getT6() {
		return t6;
	}

	public void setT6(String t6) {
		this.t6 = t6;
	}

	public String getT7() {
		return t7;
	}

	public void setT7(String t7) {
		this.t7 = t7;
	}

	public String getT8() {
		return t8;
	}

	public void setT8(String t8) {
		this.t8 = t8;
	}

	public String getT9() {
		return t9;
	}

	public void setT9(String t9) {
		this.t9 = t9;
	}

	public String getDBempty() {
		return DBempty;
	}

	public void setDBempty(String dBempty) {
		DBempty = dBempty;
	}

}
