package _12_0_memberSearch;

public class MSService {

}
