package _8_UserInfoUpdateA;

public class UiaDAO {

}
