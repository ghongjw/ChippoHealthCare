package _8_UserInfoUpdateA;

public class UiaService {
	

}
