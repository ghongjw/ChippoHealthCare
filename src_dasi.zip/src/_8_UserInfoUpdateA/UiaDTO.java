package _8_UserInfoUpdateA;

import java.util.Set;

public class UiaDTO {
	
	private String pw;
	
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}

}
