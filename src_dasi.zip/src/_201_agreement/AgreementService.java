package _201_agreement;

import javafx.scene.Parent;

public class AgreementService {
		public void agreProc(Parent agreement) {
			
		}
}
