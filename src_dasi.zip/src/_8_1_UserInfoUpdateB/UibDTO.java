package _8_1_UserInfoUpdateB;

public class UibDTO {

	private String pw, pwcon, email, emailbox, phone, address, gender, point, men, women, addemail;

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getPwcon() {
		return pwcon;
	}

	public void setPwcon(String pwcon) {
		this.pwcon = pwcon;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPoint() {
		return point;
	}

	public void setPoint(String point) {
		this.point = point;
	}

	public void setEmailbox(String emailbox) {
		this.emailbox = emailbox;
	}

	public String getEmailbox() {
		return emailbox;
	}

	public String getMen() {
		return men;
	}

	public void setMen(String men) {
		this.men = men;
	}

	public String getWomen() {
		return women;
	}

	public void setWomen(String women) {
		this.women = women;
	}
	
	public void setAddemail(String addemail) {
		this.addemail = addemail;
	}public String getAddemail() {
		return addemail;
	}

}
