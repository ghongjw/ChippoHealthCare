package _9_UserPTUpdate;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;
import javafx.scene.Parent;

public class UPController2 implements Initializable{
	
	private UPService upservice;
	private Parent boForm;
	
	
	{
}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
