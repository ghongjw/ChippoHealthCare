package _6_Record;

public class RcDTO {

}
