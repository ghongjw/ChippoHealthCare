package _7_1_inbodyResister;

import java.time.LocalDate;

import javafx.scene.control.DatePicker;

public class InbodyRegDTO {

	private String age, height, weight, musle, fat, fatper, bmi, year, month, day, dates;

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getMusle() {
		return musle;
	}

	public void setMusle(String musle) {
		this.musle = musle;
	}

	public String getfat() {
		return fat;
	}

	public void setfat(String fat) {
		this.fat = fat;
	}

	public String getfatper() {
		return fatper;
	}

	public void setfatper(String fatper) {
		this.fatper = fatper;
	}

	public String getBmi() {
		return bmi;
	}

	public void setBmi(String bmi) {
		this.bmi = bmi;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getDates() {
		return dates;
	}

	public void setDates(String dates) {
		this.dates = dates;
	}

}
